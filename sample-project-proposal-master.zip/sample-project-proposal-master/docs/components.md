## Component Hierarchy

* `App`
  * `SearchIndex`
  * `NotebooksIndex`
    * `NotebookIndexItem`
  * `NotebookForm`
  * `NotesIndex`
    * `NoteForm`
    * `NoteIndexItem`
  * `NoteDetail`
    * `NoteTags`
    * `NoteEditArea`
